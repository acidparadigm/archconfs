#### Colors Repo
  - You can find me on linuxbbq
  - This repo is a small subset of my colour collection for Github
  - I like to keep it simple with only 9 colors. Main reason I choose to setup my configs like this  

#### Implementation
  - Use the example from xresource file to include in .Xresources

#### Previews

###### raiin 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/raiin.png)

###### bulb 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/bulb.png)

###### novmbr 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/novmbr.png)

###### branch 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/branch.png)

###### wintry 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/wintry.png)

###### newleaf 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/newleaf.png)

###### schredd 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/schredd.png)

###### fury 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/fury.png)

###### squares 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/squares.png)

###### harbing 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/harbing.png)

###### poly
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/poly.png)

###### victory
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/victory.png)

###### bark
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/bark.png)

###### reloaded
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/reloaded.png)

###### depth
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/depth.png)

###### scag
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/scag.png)

###### leaf
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/leaf.png)

###### designr
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/designr.png)

###### mattd 
![alt tag](https://github.com/dkeg/crayolo/blob/master/preview/mattd.png)
